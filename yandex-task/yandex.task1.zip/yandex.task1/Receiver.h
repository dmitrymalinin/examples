#pragma once

class Receiver
{
public:

	Receiver(void)
	{
	}

	~Receiver(void)
	{
	}

	void run()
	{
		hMapFile = NULL;
		pBuf = NULL;
		// ������� ��� ������� CounterWriteEvent
		HANDLE hCounterWriteEvent = CreateEvent(
			NULL,
			TRUE, // bManualReset,
			FALSE, // bInitialState,
			CounterWriteEventName
			);
		if (!hCounterWriteEvent)
		{
			helper::Print_sync(TEXT("Receiver: Could not create CounterWriteEvent.\n%s\n"), 
				helper::GetLastOSErrorMsg().c_str());
			return;
		}

		/*HANDLE hCounterReadEvent = CreateEvent(
			NULL,
			TRUE, // bManualReset,
			TRUE, // bInitialState,
			CounterReadEventName
			);*/

		/*HANDLE hCounterWriteMutex = CreateMutex(
			NULL,
			FALSE, //bInitialOwner,
			CounterWriteMutexName
		);*/

		helper::Print_sync(TEXT("Receiver: I am rinning\n"));


		while(true)
		{
			DWORD WaitResult = WaitForSingleObject(hCounterWriteEvent, INFINITE);  
			if (WaitResult == WAIT_OBJECT_0)
			{
				if (!read()) break;
			} else
			{
				helper::Print_sync(TEXT("Receiver: Wait CounterWriteEvent failed.\n%s\n"), 
					helper::GetLastOSErrorMsg().c_str());		
				break;
			}

		}
		CloseHandle(hCounterWriteEvent);
		if (hMapFile) 
		{
			if (pBuf) UnmapViewOfFile(pBuf);
			CloseHandle(hMapFile);
		}
	}


private:

	HANDLE hMapFile;
	LPTSTR pBuf;

	bool read()
	{
		if (!hMapFile)
		{
			hMapFile = OpenFileMapping(
				FILE_MAP_READ,   // dwDesiredAccess
				FALSE,           // bInheritHandle,
				FileMappingName);

			if (!hMapFile) 
			{ 
				helper::Print_sync(TEXT("Receiver: Could not open file mapping object.\n%s\n"), 
					helper::GetLastOSErrorMsg().c_str());
				return false;
			} 


			pBuf = (LPTSTR) MapViewOfFile(hMapFile, // handle to map object
				FILE_MAP_READ,  // read/write permission
				0,                    
				0,                    
				FileMappingBufSize);                   

			if (pBuf == NULL) 
			{ 
				helper::Print_sync(TEXT("Receiver: Could not map view of file.\n%s\n"), 
					helper::GetLastOSErrorMsg().c_str());
				//CloseHandle(hMapFile);
				return false;
			}
		}

		helper::Print_sync(TEXT("Receiver: %s\n"), pBuf);

//		UnmapViewOfFile(pBuf);

//		CloseHandle(hMapFile);

		return true;
	}
};
