// yandex.task1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

//HANDLE hMapFile;


int _tmain(int argc, _TCHAR* argv[])
{

	InitializeCriticalSection(&helper::PrintCriticalSection);

	

	// ������� ����� ��� ����������
	DWORD DispThreadId;
	HANDLE hDispThread = CreateThread(
		NULL,
		0, 
		Dispatcher::Thread,
		NULL,
		0,
		&DispThreadId
	);

	if (!hDispThread)
	{
		helper::Print_sync(TEXT("main: Could not create thread for dispatcher.\n%s\n"), 
			helper::GetLastOSErrorMsg().c_str());
		return 1;
	}

	Receiver recv;
	recv.run();

	_getch();

	DeleteCriticalSection(&helper::PrintCriticalSection);	
	CloseHandle(hDispThread);

	

	return 0;
}

