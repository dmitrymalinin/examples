#include "stdafx.h"

CRITICAL_SECTION helper::PrintCriticalSection;
